import { LightningElement, track } from 'lwc';

export default class PermissionSetMgr extends LightningElement {
    @track availList = [
        { label: 'ActorCASCPermSet', value: '1', description: 'Access to Actor records' },
        { label: 'Buyer', value: '2', description: 'Standard buyer access' },
        { label: 'Portal Access', value: '3', description: 'General CRM access' },
         { label: 'EU Store Access', value: '4', description: 'Permission set for users to login in European Union store for purchasing products' },
          { label: 'NAM Store Access', value: '5', description: 'General CRM access' },
           { label: 'LATAM Store Access', value: '6', description: 'General CRM access' },
            { label: 'APAC Store Access', value: '7', description: 'General CRM access' },
             { label: 'Enable MFA login', value: '8', description: 'General CRM access' },
              { label: 'View All Records PS', value: '9', description: 'General CRM access' },
               { label: 'Create Records PS', value: '10', description: 'General CRM access' },
                { label: 'CRUD Access', value: '11', description: 'General CRM access' },
                 { label: 'Admin Access User', value: '12', description: 'General CRM access' },
                  { label: 'Only Customer User', value: '13', description: 'General CRM access' },
                   { label: 'CRM User', value: '14', description: 'General CRM access' }
    ];
    @track selectedList = [];
    
    searchKeyAvail = '';
    searchKeySelect = '';
    selectedId = ''; // Stores which ID is currently clicked/highlighted
    selectedSide = ''; // Stores which side the clicked item is on

    // --- 1. FILTERING LOGIC ---
    get filteredAvailable() {
        return this.availList
            .filter(item => item.label.toLowerCase().includes(this.searchKeyAvail.toLowerCase()))
            .map(item => this.applyStyles(item, 'available'));
    }

    get filteredSelected() {
        return this.selectedList
            .filter(item => item.label.toLowerCase().includes(this.searchKeySelect.toLowerCase()))
            .map(item => this.applyStyles(item, 'selected'));
    }

    // Helper to add CSS classes to items
    applyStyles(item, side) {
        let isHighlighted = (this.selectedId === item.value && this.selectedSide === side);
        return {
            ...item,
            className: `slds-listbox__option list-item ${isHighlighted ? 'is-selected' : ''}`
        };
    }

    // --- 2. SEARCH & ERROR LOGIC ---
    handleSearchAvail(event) { this.searchKeyAvail = event.target.value; }
    handleSearchSelect(event) { this.searchKeySelect = event.target.value; }

    get isAvailEmpty() { return this.searchKeyAvail !== '' && this.filteredAvailable.length === 0; }
    get isSelectedEmpty() { return this.searchKeySelect !== '' && this.filteredSelected.length === 0; }

    get availSearchClass() { return this.isAvailEmpty ? 'slds-has-error' : ''; }
    get selectSearchClass() { return this.isSelectedEmpty ? 'slds-has-error' : ''; }

    // --- 3. MOVEMENT LOGIC ---
    handleItemClick(event) {
        this.selectedId = event.currentTarget.dataset.value;
        this.selectedSide = event.currentTarget.dataset.side;
    }

    moveRight() {
        if (this.selectedSide !== 'available') return;
        const itemIndex = this.availList.findIndex(i => i.value === this.selectedId);
        if (itemIndex !== -1) {
            const item = this.availList.splice(itemIndex, 1)[0]; // Remove from Left
            this.selectedList.push(item); // Add to Right
            this.selectedId = ''; // Clear selection
        }
    }

    moveLeft() {
        if (this.selectedSide !== 'selected') return;
        const itemIndex = this.selectedList.findIndex(i => i.value === this.selectedId);
        if (itemIndex !== -1) {
            const item = this.selectedList.splice(itemIndex, 1)[0]; // Remove from Right
            this.availList.push(item); // Add to Left
            this.selectedId = ''; // Clear selection
        }
    }
}